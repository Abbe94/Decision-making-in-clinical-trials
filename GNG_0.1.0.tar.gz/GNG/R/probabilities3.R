probabilities3=function(TV,LRV,n,sigma,rho,Delta,FGR=c(0.2, 0.2),FSR=c(0.1, 0.1)){
  # Calculates the probabilities of the decisions when we have 2 endpoints
  # and truth=Delta=c(Delta[1],Delta[2])

  # Input variables:
  # TV=c(TV1,TV2) is a vector with the TV's for each endpoint
  # LRV=c(LRV1,LRV2) is a vector with the LRV's for each endpoint
  # n=total sample size (2 times the sample size per arm)
  # sigma=c(sigma1,sigma2) is a vector with the standard deviations for each endpoint
  # rho=correlation between the two endpoints
  # Delta=(Delta1,Delta2) is the vector of the true values of each endpoint (usually, Delta=TV or Delta=LRV)
  # FGR=c(FGR1,FGR2) is the vector of the False go risks for each endpoint (usually, FGR=c(0.2, 0.2))
  # FSR=c(FSR1,FSR2) is the vector of the False stop risks for each endpoint (usually, FSR=c(0.1, 0.1))

  s1=sqrt(4*sigma[1]^2/n)
  s2=sqrt(4*sigma[2]^2/n)
  a1=LRV[1]-qnorm(FGR[1])*s1
  a2=LRV[2]-qnorm(FGR[2])*s2
  b1=TV[1]-qnorm(1-FSR[1])*s1
  b2=TV[2]-qnorm(1-FSR[2])*s2
  c1=max(a1,b1)
  c2=max(a2,b2)
  d1=min(a1,b1)
  d2=min(a2,b2)
  covmatrix=matrix(data = c(s1^2,s1*s2*rho,s1*s2*rho,s2^2),nrow = 2,ncol = 2)

  # Now, let's calculate the probabilities

  # pGG
  pGG=pmvnorm(lower = c(c1,c2), upper = rep(Inf,2), mean = Delta, sigma = covmatrix)

  # pGA
  pGA=pmvnorm(lower = c(c1,d2),upper = c(Inf,c2), mean = Delta, sigma = covmatrix)

  # pAG
  pAG=pmvnorm(lower = c(d1,c2),upper = c(c1,Inf), mean = Delta, sigma = covmatrix)

  # pRA
  pRA=pmvnorm(lower = c(-Inf,d2),upper = c(d1,c2), mean = Delta, sigma = covmatrix)

  # pAA
  pAA=pmvnorm(lower = c(d1,d2),upper = c(c1,c2), mean = Delta, sigma = covmatrix)

  # pAR
  pAR=pmvnorm(lower = c(d1,-Inf),upper = c(c1,d2), mean = Delta, sigma = covmatrix)

  # pRG
  pRG=pmvnorm(lower = c(-Inf,c2),upper = c(d1,Inf), mean = Delta, sigma = covmatrix)

  # pGR
  pGR=pmvnorm(lower = c(c1,-Inf),upper = c(Inf,d2), mean = Delta, sigma = covmatrix)

  # pRR
  pRR=pmvnorm(lower = c(-Inf,-Inf),upper = c(d1,d2), mean = Delta, sigma = covmatrix)

  p=c(pGG,pGA,pAG,pRG,pGR,pAA,pRA,pAR,pRR)
  return(p)
}
