stepwiseprobabilities3=function(TV,LRV,sigma,n,rho,FGR=c(0.2, 0.2, 0.2),FSR=c(0.1, 0.1, 0.1)){
  # Calculates the probabilities of the decisions assuming the truth either fulfills the TV or
  # the LRV when using stepwise GNG criteria with 3 endpoints

  pTV=probabilities4(TV=TV, LRV=LRV, Delta = TV, sigma0 = sigma, rho = rho, n, FGR = FGR, FSR = FSR)
  pLRV=probabilities4(TV=TV, LRV=LRV, Delta = LRV, sigma0 = sigma, rho = rho, n, FGR = FGR, FSR = FSR)

  # P(G|TV) and P(G|LRV)
  pGgTV=pTV[1]+pTV[2]+pTV[3]+pTV[4]+pTV[5]+pTV[6]+pTV[8]+pTV[9]+pTV[10]+pTV[11]+pTV[12]+pTV[13]+pTV[16]
  pGgLRV=pLRV[1]+pLRV[2]+pLRV[3]+pLRV[4]+pLRV[5]+pLRV[6]+pLRV[8]+pLRV[9]+pLRV[10]+pLRV[11]+pLRV[12]+pLRV[13]+pLRV[16]

  # P(A|TV) and P(A|LRV)
  pAgTV=pTV[20]
  pAgLRV=pLRV[20]

  # P(R|TV) and P(R|LRV)
  pRgTV=pTV[7]+pTV[14]+pTV[15]+pTV[17]+pTV[18]+pTV[19]+pTV[21]+pTV[22]+pTV[23]+pTV[24]+pTV[25]+pTV[26]+pTV[27]
  pRgLRV=pLRV[7]+pLRV[14]+pLRV[15]+pLRV[17]+pLRV[18]+pLRV[19]+pLRV[21]+pLRV[22]+pLRV[23]+pLRV[24]+pLRV[25]+pLRV[26]+pLRV[27]

  return(c(pGgTV,pGgLRV,pAgTV,pAgLRV,pRgTV,pRgLRV))
}
