oneofoneprobs=function(TV,LRV,n,sigma,FGR=0.2,FSR=0.1){
  # Calculates the probabilities of the decisions assuming the truth either fulfills the TV or
  # the LRV when using only one endpoint
  
  s=sqrt(4*sigma^2/n)
  a=LRV-qnorm(FGR)*s
  b=TV-qnorm(1-FSR)*s
  c=max(a,b)
  d=min(a,b)
  
  # P(G|TV) and P(G|LRV)
  pGgTV=1-pnorm(c, mean = TV, sd=s)
  pGgLRV=1-pnorm(c, mean = LRV, sd=s)
  
  # P(A|TV) and P(A|LRV)
  pAgTV=pnorm(c, mean = TV, sd=s)-pnorm(d, mean = TV, sd=s)
  pAgLRV=pnorm(c, mean = LRV, sd=s)-pnorm(d, mean = LRV, sd=s)
  
  # P(R|TV) and P(R|LRV)
  pRgTV=pnorm(d, mean = TV, sd=s)
  pRgLRV=pnorm(d, mean = LRV, sd=s)
  
  return(c(pGgTV,pGgLRV,pAgTV,pAgLRV,pRgTV,pRgLRV))
}