condprob2=function(TV,LRV,n,sigma,rho,FGR=c(0.2, 0.2),FSR=c(0.1, 0.1)){
  # Calculates the conditional probabilities for the decisions of endpoint 2,
  # given that we have made the decision Amber for endpoint 1.
  
  # Input variables:
  # TV=c(TV1,TV2) is a vector with the TV's for each endpoint
  # LRV=c(LRV1,LRV2) is a vector with the LRV's for each endpoint
  # n=total sample size (2 times the sample size per arm)
  # sigmao=c(sigmao1,sigmao2) is a vector with the standard deviations for each endpoint
  # rho=correlation between the two endpoints
  # FGR=c(FGR1,FGR2) is the vector of the False go risks for each endpoint (usually, FGR=c(0.2, 0.2))
  # FSR=c(FSR1,FSR2) is the vector of the False stop risks for each endpoint (usually, FSR=c(0.1, 0.1))
  s1=sqrt(4*sigma[1]^2/n)
  s2=sqrt(4*sigma[2]^2/n)
  a1=LRV[1]-qnorm(FGR[1])*s1
  a2=LRV[2]-qnorm(FGR[2])*s2
  b1=TV[1]-qnorm(1-FSR[1])*s1
  b2=TV[2]-qnorm(1-FSR[2])*s2
  c1=max(a1,b1)
  c2=max(a2,b2)
  d1=min(a1,b1)
  d2=min(a2,b2)
  covmatrix=matrix(data = c(s1^2,s1*s2*rho,s1*s2*rho,s2^2),nrow = 2,ncol = 2)
  
  # now, let's calculate P(G) w.r.t. endpoint 2, given Amber w.r.t. endpoint 1
  pGgATV=pmvnorm(lower = c(d1,c2), upper = c(c1,Inf), mean = TV, sigma = covmatrix)/(pnorm(c1, mean = TV[1], sd=s1)-pnorm(d1, mean = TV[1], sd=s1))
  pGgALRV=pmvnorm(lower = c(d1,c2), upper = c(c1,Inf), mean = LRV, sigma = covmatrix)/(pnorm(c1, mean = LRV[1], sd=s1)-pnorm(d1, mean = LRV[1], sd=s1))
  
  # now, let's calculate P(R) w.r.t. endpoint 2, given Amber w.r.t. endpoint 1
  pRgATV=pmvnorm(lower = c(d1,-Inf), upper = c(c1,d2), mean = TV, sigma = covmatrix)/(pnorm(c1, mean = TV[1], sd=s1)-pnorm(d1, mean = TV[1], sd=s1))
  pRgALRV=pmvnorm(lower = c(d1,-Inf), upper = c(c1,d2), mean = LRV, sigma = covmatrix)/(pnorm(c1, mean = LRV[1], sd=s1)-pnorm(d1, mean = LRV[1], sd=s1))
  
  # now, let's calculate P(A) w.r.t. endpoint 2, given Amber w.r.t. endpoint 1
  pAgATV=pmvnorm(lower = c(d1,d2), upper = c(c1,c2), mean = TV, sigma = covmatrix)/(pnorm(c1, mean = TV[1], sd=s1)-pnorm(d1, mean = TV[1], sd=s1))
  pAgALRV=pmvnorm(lower = c(d1,d2), upper = c(c1,c2), mean = LRV, sigma = covmatrix)/(pnorm(c1, mean = LRV[1], sd=s1)-pnorm(d1, mean = LRV[1], sd=s1))
  
  p=c(pGgATV, pGgALRV, pAgATV, pAgALRV, pRgATV, pRgALRV)
  return(p)
}