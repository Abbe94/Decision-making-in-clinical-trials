probabilities4=function(TV,LRV,Delta,sigma0,rho,n,FGR=c(0.2, 0.2, 0.2),FSR=c(0.1, 0.1, 0.1)){
  # Calculates the probabilities of the decisions when #endpoints=3

  # Input variables:
  # TV=c(TV1,TV2,TV3) is a vector with the TV's for each endpoint
  # LRV=c(LRV1,LRV2,LRV3) is a vector with the LRV's for each endpoint
  # n=total sample size (2 times the sample size per arm)
  # sigma=c(sigma1,sigma2,sigma3) is a vector with the standard deviations for each endpoint
  # rho=correlation matrix for deltahat=c(deltahat1, deltahat2, deltahat3)
  # Delta=c(Delta1,Delta2,Delta3) is the vector of the true values of each endpoint (usually, Delta=TV or Delta=LRV)
  # FGR=c(FGR1,FGR2,FGR3) is the vector of the False go risk's for each endpoint (Default: FGR=c(0.2, 0.2, 0.2))
  # FSR=c(FSR1,FSR2,FSR3) is the vector of the False stop risk's for each endpoint (Default: FSR=c(0.1, 0.1, 0.1))
  s1=sqrt(4*sigma0[1]^2/n)
  s2=sqrt(4*sigma0[2]^2/n)
  s3=sqrt(4*sigma0[3]^2/n)
  a1=LRV[1]-qnorm(FGR[1])*s1
  a2=LRV[2]-qnorm(FGR[2])*s2
  a3=LRV[3]-qnorm(FGR[3])*s3
  b1=TV[1]-qnorm(1-FSR[1])*s1
  b2=TV[2]-qnorm(1-FSR[2])*s2
  b3=TV[3]-qnorm(1-FSR[3])*s3
  c1=max(a1,b1)
  c2=max(a2,b2)
  c3=max(a3,b3)
  d1=min(a1,b1)
  d2=min(a2,b2)
  d3=min(a3,b3)
  covmatrix=matrix(data = c(s1^2,s1*s2*rho[1,2],s1*s3*rho[1,3],s1*s2*rho[1,2],s2^2,s2*s3*rho[2,3],s1*s3*rho[1,3],s2*s3*rho[2,3],s3^2),nrow = 3, ncol = 3, byrow = T)

  # now, let's calculate the 27 probabilities

  # pGGG
  pGGG=pmvnorm(lower = c(c1,c2,c3), upper = rep(Inf,3), mean = Delta, sigma = covmatrix)

  # pGGA
  pGGA=pmvnorm(lower = c(c1,c2,d3), upper = c(Inf,Inf,c3), mean = Delta, sigma = covmatrix)

  # pGGR
  pGGR=pmvnorm(lower = c(c1,c2,-Inf), upper = c(Inf,Inf,d3), mean = Delta, sigma = covmatrix)

  # pGAG
  pGAG=pmvnorm(lower = c(c1,d2,c3), upper = c(Inf,c2,Inf), mean = Delta, sigma = covmatrix)

  # pGRG
  pGRG=pmvnorm(lower = c(c1,-Inf,c3), upper = c(Inf,d2,Inf), mean = Delta, sigma = covmatrix)

  # pAGG
  pAGG=pmvnorm(lower = c(d1,c2,c3), upper = c(c1,Inf,Inf), mean = Delta, sigma = covmatrix)

  # pRGG
  pRGG=pmvnorm(lower = c(-Inf,c2,c3), upper = c(d1,Inf,Inf), mean = Delta, sigma = covmatrix)

  # pGAA
  pGAA=pmvnorm(lower = c(c1,d2,d3), upper = c(Inf,c2,c3), mean = Delta, sigma = covmatrix)

  # pGAR
  pGAR=pmvnorm(lower = c(c1,d2,-Inf), upper = c(Inf,c2,d3), mean = Delta, sigma = covmatrix)

  # pGRA
  pGRA=pmvnorm(lower = c(c1,-Inf,d3), upper = c(Inf,d2,c3), mean = Delta, sigma = covmatrix)

  # pGRR
  pGRR=pmvnorm(lower = c(c1,-Inf,-Inf), upper = c(Inf,d2,d3), mean = Delta, sigma = covmatrix)

  # pAGA
  pAGA=pmvnorm(lower = c(d1,c2,d3), upper = c(c1,Inf,c3), mean = Delta, sigma = covmatrix)

  # pAGR
  pAGR=pmvnorm(lower = c(d1,c2,-Inf), upper = c(c1,Inf,d3), mean = Delta, sigma = covmatrix)

  # pRGA
  pRGA=pmvnorm(lower = c(-Inf,c2,d3), upper = c(d1,Inf,c3), mean = Delta, sigma = covmatrix)

  # pRGR
  pRGR=pmvnorm(lower = c(-Inf,c2,-Inf), upper = c(d1,Inf,d3), mean = Delta, sigma = covmatrix)

  # pAAG
  pAAG=pmvnorm(lower = c(d1,d2,c3), upper = c(c1,c2,Inf), mean = Delta, sigma = covmatrix)

  # pARG
  pARG=pmvnorm(lower = c(d1,-Inf,c3), upper = c(c1,d2,Inf), mean = Delta, sigma = covmatrix)

  # pRAG
  pRAG=pmvnorm(lower = c(-Inf,d2,c3), upper = c(d1,c2,Inf), mean = Delta, sigma = covmatrix)

  # pRRG
  pRRG=pmvnorm(lower = c(-Inf,-Inf,c3), upper = c(d1,d2,Inf), mean = Delta, sigma = covmatrix)

  # pAAA
  pAAA=pmvnorm(lower = c(d1,d2,d3), upper = c(c1,c2,c3), mean = Delta, sigma = covmatrix)

  # pAAR
  pAAR=pmvnorm(lower = c(d1,d2,-Inf), upper = c(c1,c2,d3), mean = Delta, sigma = covmatrix)

  # pARA
  pARA=pmvnorm(lower = c(d1,-Inf,d3), upper = c(c1,d2,c3), mean = Delta, sigma = covmatrix)

  # pRAA
  pRAA=pmvnorm(lower = c(-Inf,d2,d3), upper = c(d1,c2,c3), mean = Delta, sigma = covmatrix)

  # pRRA
  pRRA=pmvnorm(lower = c(-Inf,-Inf,d3), upper = c(d1,d2,c3), mean = Delta, sigma = covmatrix)

  # pRAR
  pRAR=pmvnorm(lower = c(-Inf,d2,-Inf), upper = c(d1,c2,d3), mean = Delta, sigma = covmatrix)

  # pARR
  pARR=pmvnorm(lower = c(d1,-Inf,-Inf), upper = c(c1,d2,d3), mean = Delta, sigma = covmatrix)

  # pRRR
  pRRR=pmvnorm(lower = rep(-Inf,3), upper = c(d1,d2,d3), mean = Delta, sigma = covmatrix)

  return(c(pGGG,pGGA,pGGR,pGAG,pGRG,pAGG,pRGG,pGAA,pGAR,pGRA,pGRR,pAGA,pAGR,pRGA,pRGR,pAAG,pARG,pRAG,pRRG,pAAA,pAAR,pARA,pRAA,pRRA,pRAR,pARR,pRRR))
}
