oneoftwoprobs=function(TV,LRV,n,sigma,rho,FGR=c(0.2, 0.2),FSR=c(0.1, 0.1)){
  # Calculates the probabilities of the decisions assuming the truth either fulfills the TV or
  # the LRV when using 1-of-2 GNG criteria with 2 endpoints
  
  pTV=probabilities3(TV,LRV,n,sigma,rho,TV,FGR,FSR)
  pLRV=probabilities3(TV,LRV,n,sigma,rho,LRV,FGR,FSR)
  
  # P(G|TV) and P(G|LRV)
  pGgTV=pTV[1]+pTV[2]+pTV[3]
  pGgLRV=pLRV[1]+pLRV[2]+pLRV[3]
  
  # P(A|TV) and P(A|LRV)
  pAgTV=pTV[4]+pTV[5]+pTV[6]
  pAgLRV=pLRV[4]+pLRV[5]+pLRV[6]
  
  # P(R|TV) and P(R|LRV)
  pRgTV=pTV[7]+pTV[8]+pTV[9]
  pRgLRV=pLRV[7]+pLRV[8]+pLRV[9]
  
  return(c(pGgTV,pGgLRV,pAgTV,pAgLRV,pRgTV,pRgLRV))
}