Amberoneoftwoprobs=function(TV,LRV,sigma,rho,n,FGR=c(0.2,0.2,0.2),FSR=c(0.1,0.1,0.1)){
  # Calculates the probabilities of the decisions assuming the truth either fulfills the TV or
  # the LRV when using the stepwise 1-of-2 GNG criteria with 3 endpoints.

  ppTV=probabilities4(TV,LRV,Delta=TV,sigma0=sigma,rho,n,FGR=FGR,FSR=FSR)
  ppLRV=probabilities4(TV,LRV,Delta=LRV,sigma0=sigma,rho,n,FGR=FGR,FSR=FSR)

  pGgTV=ppTV[1]+ppTV[2]+ppTV[3]+ppTV[4]+ppTV[5]+ppTV[6]+ppTV[8]+ppTV[9]+ppTV[10]+ppTV[11]+ppTV[12]+ppTV[16]
  pAgTV=ppTV[20]
  pRgTV=ppTV[7]+ppTV[13]+ppTV[14]+ppTV[15]+ppTV[17]+ppTV[18]+ppTV[19]+ppTV[21]+ppTV[22]+ppTV[23]+ppTV[24]+ppTV[25]+ppTV[26]+ppTV[27]

  pGgLRV=ppLRV[1]+ppLRV[2]+ppLRV[3]+ppLRV[4]+ppLRV[5]+ppLRV[6]+ppLRV[8]+ppLRV[9]+ppLRV[10]+ppLRV[11]+ppLRV[12]+ppLRV[16]
  pAgLRV=ppLRV[20]
  pRgLRV=ppLRV[7]+ppLRV[13]+ppLRV[14]+ppLRV[15]+ppLRV[17]+ppLRV[18]+ppLRV[19]+ppLRV[21]+ppLRV[22]+ppLRV[23]+ppLRV[24]+ppLRV[25]+ppLRV[26]+ppLRV[27]

  return(c(pGgTV, pGgLRV, pAgTV, pAgLRV, pRgTV, pRgLRV))
}
